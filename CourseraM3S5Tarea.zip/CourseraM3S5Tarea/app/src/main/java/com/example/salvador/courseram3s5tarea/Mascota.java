package com.example.salvador.courseram3s5tarea;

/**
 * Created by Salvador on 11/06/2016.
 */
public class Mascota {
    int id; String nombre; int foto; int cantLikes;

    public Mascota () {  }

    public Mascota(int id, String nombre) {
        this.id = id;
        this.nombre = nombre;
    }

    public Mascota(int id, String nombre, int foto, int cantLikes) {

        this.id = id;
        this.nombre = nombre;
        this.foto = foto;
        this.cantLikes = cantLikes;
    }

    public int getId() {        return id;    }

    public void setId(int id) {
        this.id = id;
    }

    public String getNombre() {
        return nombre;
    }

    public void setNombre(String nombre) {
        this.nombre = nombre;
    }

    public int getFoto() {
        return foto;
    }

    public void setFoto(int foto) {
        this.foto = foto;
    }
    public int getCantLikes() {
        return cantLikes;
    }

    public void setCantLikes(int cantLikes) {
        this.cantLikes = cantLikes;
    }


}
