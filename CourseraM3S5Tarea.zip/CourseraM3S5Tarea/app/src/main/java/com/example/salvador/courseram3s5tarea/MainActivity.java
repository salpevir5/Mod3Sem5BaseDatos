package com.example.salvador.courseram3s5tarea;

import android.content.ContentValues;
import android.database.Cursor;
import android.database.sqlite.SQLiteDatabase;
import android.support.v7.app.AppCompatActivity;
import android.os.Bundle;
import android.support.v7.widget.RecyclerView;
import android.widget.TextView;
import android.widget.Toast;

import java.util.ArrayList;

public class MainActivity extends AppCompatActivity {
    RecyclerView ListaMascotas;
    static ArrayList<Mascota> m1 = new ArrayList<Mascota> ();
    static ArrayList<Mascota> m2 = new ArrayList<Mascota> ();
    SQLiteDatabase db;

    void init_mascotas() {
        m1.add(new Mascota(1,"aaaaaa"));
        m1.add(new Mascota(2,"bbbbbb"));
        m1.add(new Mascota(3,"cccccc"));
        m1.add(new Mascota(4,"dddddd"));
        m1.add(new Mascota(5,"eeeeee"));
    }
    void despMascotas(ArrayList<Mascota> m)
    { int k;
        for (k=0; k < m.size(); k++)
            msg("Mascotaxx: " + k + m.get(k).getId() + "/" + m.get(k).getNombre());
    }
    void guardaMascotas(ArrayList<Mascota> m)
    { int k;
        ContentValues valores = new ContentValues();
        for (k=0; k < m.size(); k++)
        { // msg("Insert mascota: " + m.get(k).getNombre());
            // valores.put("id", 1); valores.put("nombre", "AAAAAA");
            valores.put("id",m.get(k).getId()); valores.put("nombre", m.get(k).getNombre());
            // msg(valores.get("id").toString() + " " + valores.get("nombre").toString());
            // db.insert("Mascotas", "", valores);
            String cmd = "insert into mascotas values(" + m.get(k).getId() +
                    ", \"" + m.get(k).getNombre() + "\")"; // msg(cmd);
            db.execSQL (cmd);   // Con db.insert no inserta Filas
        }

    }
    ArrayList<Mascota> leeMascotas ()
    { ArrayList<Mascota> m = new ArrayList<Mascota> ();
        int k = 1;
        // m.add(new Mascota(1,"wwwwww"));  m.add(new Mascota(1,"xxxxxx"));
        // m.add(new Mascota(1,"yyyyyy"));  m.add(new Mascota(1,"zzzzzz"));
        String cmd = "select * from mascotas;";
        Cursor rslt = db.rawQuery(cmd, null);
        msg("totSelected=" + rslt.getCount());
        while (rslt.moveToNext())
        { msg("Selected: " + rslt.getString(1));
            Mascota m1 = new Mascota();
            m1.setId(rslt.getInt(0)); m1.setNombre(rslt.getString(1));
            msg("Setting" + m1.getId() + " " + m1.getNombre());
            m.add(m1); ;
        }
        return m;
    }



    @Override
    protected void onCreate(Bundle savedInstanceState) {
        super.onCreate(savedInstanceState);
        setContentView(R.layout.activity_main);
        init_mascotas();
        ListaMascotas = (RecyclerView)findViewById(R.id.rvMascotas);

        BaseDatos dbh = new BaseDatos(this,"BDspv", null, 1);
        db = dbh.getWritableDatabase(); msg("DB Ready");

        init_mascotas();
        initAdapter();


        despMascotas(m1);
        guardaMascotas(m1);
        m2 = leeMascotas();
        despMascotas(m2);

    }


    public void initAdapter()
    { Adapter adaptador = new Adapter(m1);  // Data Source
        ListaMascotas.setAdapter(adaptador); // Asignar el adapter al RecyclerView
    }
    public void msg(String s)
    { Toast.makeText(this, s, Toast.LENGTH_SHORT).show();
    }

}




