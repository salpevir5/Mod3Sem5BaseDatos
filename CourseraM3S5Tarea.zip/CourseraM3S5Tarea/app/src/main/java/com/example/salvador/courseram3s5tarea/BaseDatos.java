package com.example.salvador.courseram3s5tarea;


        import android.content.ContentValues;
        import android.content.Context;
        import android.database.Cursor;
        import android.database.sqlite.SQLiteDatabase;
        import android.database.sqlite.SQLiteOpenHelper;
        import android.widget.Toast;

        import java.util.ArrayList;

/**
 * Created by Salvador on 12/06/2016.
 */
public class BaseDatos extends SQLiteOpenHelper {

    public BaseDatos(Context context, String name, SQLiteDatabase.CursorFactory factory, int version) {
        super(context, name, factory, version);
    }

    @Override
    public void onCreate(SQLiteDatabase db) {
        String cmd;
        cmd = "Create table Mascotas (mk_id integer primary key, mk_nombre Text);" ;
        db.execSQL(cmd);
    }

    @Override
    public void onUpgrade(SQLiteDatabase db, int oldVersion, int newVersion) {
        db.execSQL("drop table if exists mascotas");
        onCreate (db);
    }

    public void insertMascota(int mk_id, String mk_nombre) {
        SQLiteDatabase db = this.getReadableDatabase();
        ContentValues valores = new ContentValues();
        db.close();
    }

    public ArrayList<Mascota> selectMascotas() {
        SQLiteDatabase db = this.getReadableDatabase();
        ArrayList<Mascota> mascotas = new ArrayList<>();
        String cmd = "select * from mascotas";
        Cursor regs = db.rawQuery(cmd, null);
        while (regs.moveToNext() )
        { Mascota m = new Mascota();
            m.setId(regs.getInt(0));  // 1er campo de la tabla
            m.setNombre(regs.getString(1));  // 2º campo
            mascotas.add(m);
        }
        db.close();
        return mascotas;
    }
}

