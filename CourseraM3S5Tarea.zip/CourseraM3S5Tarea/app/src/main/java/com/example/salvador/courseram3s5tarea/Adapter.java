package com.example.salvador.courseram3s5tarea;

import android.app.Activity;
import android.content.Intent;
import android.support.v7.widget.RecyclerView;
import android.view.LayoutInflater;
import android.view.View;
import android.view.ViewGroup;
import android.widget.ImageButton;
import android.widget.ImageView;
import android.widget.TextView;
import android.widget.Toast;

import java.util.ArrayList;

public class Adapter extends
        RecyclerView.Adapter<Adapter.ViewHolder>
{ ArrayList<Mascota> mascotas;
    Activity activity;

    public Adapter(ArrayList<Mascota> mascotas)  // Constructor
    { this.mascotas = mascotas;  // Crea los datos de contactos
      this.activity = activity;
    }
    public static class ViewHolder extends RecyclerView.ViewHolder {   // Views en el CardView
        private ImageView imgFotoCV; private TextView tvNombreCV;
        private TextView tvCantLikesCV; private ImageButton btnLike;

        public ViewHolder(View itemView)  // constructor
        { super(itemView);
            imgFotoCV      = (ImageView) itemView.findViewById(R.id.imgFotoCV);
            tvNombreCV   = (TextView) itemView.findViewById(R.id.tvNombreCV);
            tvCantLikesCV = (TextView) itemView.findViewById(R.id.tvCantLikesCV);
            btnLike = (ImageButton) itemView.findViewById(R.id.btnLike);
        }
    }
    @Override //Infla el layout y lo pasa a viewholder para que él obtenga los views
    public ViewHolder onCreateViewHolder(ViewGroup parent, int viewType)
    { View v = LayoutInflater.from
                (parent.getContext()).inflate(R.layout.cardview, parent, false);
        return new ViewHolder(v);
    }

    @Override  // Cantidad de elementos en la lista
    public int getItemCount() { return mascotas.size () ; }

    @Override
    public void onBindViewHolder(ViewHolder holder, int position)
    { final Mascota m = mascotas.get(position);
        holder.imgFotoCV.setImageResource(m.getFoto() );
        holder.tvNombreCV.setText(m.getNombre());
        holder.tvCantLikesCV.setText(m.getCantLikes() );
        holder.imgFotoCV.setOnClickListener(new View.OnClickListener() {
            @Override
            public void onClick(View v) {
                Toast.makeText(activity,m.getNombre(),Toast.LENGTH_LONG).show();
                // activity se declara global en ContactoAdapter, se usa en el constructor
                Intent int1 = new Intent(activity, DetalleMascota.class);
                int1.putExtra("nombre", m.getNombre() );
                int1.putExtra("cantLikes", m.getCantLikes() );
                activity.startActivity(int1);
            }
        });

        holder.btnLike.setOnClickListener(new View.OnClickListener() {
            @Override
            public void onClick(View v) {
                Toast.makeText(activity,"Diste Like a " + m.getNombre(),
                        Toast.LENGTH_LONG).show();

            } });



    }}
